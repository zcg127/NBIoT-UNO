You can double-click to run the exe file��
Recommended exe file to send shortcuts to the desktop, easy to run later